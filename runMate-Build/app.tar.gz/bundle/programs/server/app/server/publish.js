(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publish.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
                                                                       //
Meteor.publish('AllInterest', function () {                            // 3
  return Interest.find();                                              // 4
});                                                                    //
Meteor.publish('AllTracks', function () {                              // 6
  return Tracks.find();                                                // 7
});                                                                    //
Meteor.publish('AllInterestWithoutMatched', function () {              // 9
  var MatchingList = Matching.find({ $or: [{ Male: this.userId }, { Female: this.userId }], Status: 2 }).fetch();
  var boylist = lodash.map(MatchingList, 'Male');                      // 11
  var girllist = lodash.map(MatchingList, 'Female');                   // 12
  var Arr = lodash.union(boylist, girllist);                           // 13
  console.log(Arr);                                                    // 14
  return Interest.find({ _id: { $nin: Arr } });                        // 15
});                                                                    //
Meteor.publish('AllInterestWithoutMatchedBytrackId', function (trackId) {
  var MatchingList = Matching.find({ $or: [{ Male: this.userId }, { Female: this.userId }], Status: 2 }).fetch();
  var boylist = lodash.map(MatchingList, 'Male');                      // 19
  var girllist = lodash.map(MatchingList, 'Female');                   // 20
  var Arr = lodash.union(boylist, girllist);                           // 21
                                                                       //
  console.log(Arr);                                                    // 23
  return Interest.find({ userId: { $nin: Arr }, trackId: trackId });   // 24
});                                                                    //
Meteor.publish('AllUser', function () {                                // 26
  return Meteor.users.find();                                          // 27
});                                                                    //
Meteor.publish('AllMovie', function () {                               // 29
  return Movies.find();                                                // 30
});                                                                    //
Meteor.publish('getChatroomById', function (id) {                      // 32
  return Matching.find(id);                                            // 33
});                                                                    //
Meteor.publish('getMyMatchedList', function () {                       // 35
  // console.log(this.userId());                                       //
  return Matching.find({ $or: [{ Male: this.userId }, { Female: this.userId }], Status: 2 });
});                                                                    //
                                                                       //
Meteor.publish('allUserWithOutMe', function (gender) {                 // 40
  var targetGender = gender === "male" ? "female" : "male";            // 41
  console.log(gender);                                                 // 42
  console.log(targetGender);                                           // 43
  return Meteor.users.find({ 'profile.gender': targetGender });        // 44
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
