(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/*****************************************************************************/
/*  Server Methods */                                                  //
/*****************************************************************************/
                                                                       //
Meteor.methods({                                                       // 5
  'server/method_name': function () {                                  // 6
    // server method logic                                             //
  },                                                                   //
  'updateMovie': function (trackId) {                                  // 9
    Interest.upsert({ userId: Meteor.userId() }, { $set: {             // 10
        fbID: Meteor.user().profile.id,                                // 11
        trackId: trackId,                                              // 12
        Gender: Meteor.user().profile.gender                           // 13
      } });                                                            //
  },                                                                   //
  'createMatching': function (dataObject) {                            // 16
    Matching.upsert(lodash.omit(dataObject, 'Status'), { $inc: { Status: 1 } });
    // Matching.upsert(lodash.omit(dataObject,'Status'),{$inc:{Status:2}});
                                                                       //
    var matchingObj = Matching.findOne(lodash.omit(dataObject, 'Status'));
                                                                       //
    return matchingObj.Status === 2 ? matchingObj._id : false;         // 23
  },                                                                   //
  'sendMsg': function (dataObject) {                                   // 29
    console.log('start sendMsg');                                      // 30
    console.log(dataObject);                                           // 31
    var modifier = {};                                                 // 32
    var chatObj = {};                                                  // 33
    chatObj.from = Meteor.userId();                                    // 34
    chatObj.to = Meteor.userId() === dataObject.Male ? dataObject.Female : dataObject.Male;
    chatObj.sendAt = new Date().getTime();                             // 36
    chatObj.text = dataObject.text;                                    // 37
    modifier.$push = { chat: chatObj };                                // 38
    Matching.update(dataObject._id, modifier);                         // 39
  },                                                                   //
  'setbadge': function (arr) {                                         // 42
    console.log(arr);                                                  // 43
    Meteor.users.update({ _id: { $in: arr } }, { $set: { notice: true } });
  },                                                                   //
  'setNoticeFalse': function (argument) {                              // 47
    Meteor.users.update(Meteor.userId(), { $set: { notice: false } });
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
