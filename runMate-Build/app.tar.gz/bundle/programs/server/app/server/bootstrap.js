(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/bootstrap.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
                                                                       //
  ServiceConfiguration.configurations.upsert({ service: "facebook" }, { $set: { appId: "1915957638628550", secret: "08e9bc7e0f9f85c5fe246fd1a296de7a" } });
  Meteor.users.remove({});                                             // 7
  Interest.remove({});                                                 // 8
  Matching.remove({});                                                 // 9
  Tracks.remove({});                                                   // 10
                                                                       //
  var ids = [];                                                        // 12
  ids.push(560498514); //She is my gf!!!!                              // 13
  ids.push(503674580);                                                 // 14
  ids.push(100003743012797);                                           // 15
  ids.push(1428036985);                                                // 16
  ids.push(19614945368);                                               // 17
  ids.push(309787872509777);                                           // 18
  ids.push(1712329320);                                                // 19
                                                                       //
  ids.push(100000461840895);                                           // 21
  ids.push(100007881438763);                                           // 22
  ids.push(334272573297217);                                           // 23
  ids.push(1136260708);                                                // 24
  ids.push(1253321724);                                                // 25
  ids.push(1095417037);                                                // 26
  ids.push(539479940);                                                 // 27
  ids.push(1233852119);                                                // 28
  ids.push(560202378);                                                 // 29
                                                                       //
  ids.push(100000839313476);                                           // 31
  ids.push(100001383874700);                                           // 32
  ids.push(100002647722802);                                           // 33
  ids.push(1580110543);                                                // 34
  ids.push(1143527135);                                                // 35
  ids.push(839875251);                                                 // 36
  ids.push(705687935);                                                 // 37
  ids.push(557945711);                                                 // 38
  ids.push(100000022215260);                                           // 39
                                                                       //
  if (Meteor.users.find().count() === 0) {                             // 41
                                                                       //
    var tracks = [];                                                   // 43
                                                                       //
    tracks.push({ distict: "Pok Fu Lam", distance: "4.1km", name: "Victoria Road between Kennedy Town and Pok Fu Lam Road", pic: "http://i.cdn.travel.cnn.com/sites/default/files/styles/inline_image_624x416/public/2011/09/23/MaOnShan1-INLINE.jpg?itok=8E6VA9uf" });
    tracks.push({ distict: "Ma On Shan", distance: "6.2km", name: "Ma On Shan-Sha Tin Promenade", pic: "http://i.cdn.travel.cnn.com/sites/default/files/styles/inline_image_624x416/public/2011/09/23/LugardSevern5-INLINE.jpg?itok=sGFsuK_v" });
    tracks.push({ distict: "Mid Levels", distance: "8.0km", name: "Lugard Road to Severn Road figure-of-eight", pic: "http://i.cdn.travel.cnn.com/sites/default/files/styles/inline_image_624x416/public/2011/09/23/HKTrail2-INLINE.jpg?itok=Jcjh_76j" });
    tracks.push({ distict: "Sai Kung", distance: "2.6km", name: "Clear Water Bay", pic: "http://www.scmp.com/sites/default/files/styles/486w/public/2015/01/22/clearwater_bay_bruce_yan.jpg?itok=Qm5G7_WZ" });
                                                                       //
    tracks.forEach(function (element, index, array) {                  // 50
      Tracks.insert(element);                                          // 51
    });                                                                //
                                                                       //
    ids.forEach(function (element, index, array) {                     // 56
                                                                       //
      var genderArr = ['male', 'female'];                              // 58
      var user = Fake.user(); // for demo, name is generated           // 59
      var fbId = element;                                              // 60
      var link = "http://graph.facebook.com/" + fbId + "/picture?type=square";
      var gender = lodash.sample(genderArr);                           // 62
      var profile = {                                                  // 63
        email: user.email,                                             // 64
        gender: 'female',                                              // 65
        link: link,                                                    // 66
        name: user.fullname,                                           // 67
        id: fbId                                                       // 68
      };                                                               //
      var dataObject = {                                               // 70
        profile: profile                                               // 71
      };                                                               //
      var userId = Meteor.users.insert(dataObject);                    // 73
                                                                       //
      var movie = lodash.map(Tracks.find().fetch(), '_id');            // 75
                                                                       //
      var movieData = {                                                // 78
        userId: userId,                                                // 79
        fbID: fbId,                                                    // 80
        trackId: lodash.sample(movie),                                 // 81
        // Gender: gender                                              //
        Gender: 'female'                                               // 83
      };                                                               //
                                                                       //
      Interest.insert(movieData);                                      // 86
    });                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=bootstrap.js.map
