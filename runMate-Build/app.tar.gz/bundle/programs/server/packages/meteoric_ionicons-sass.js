(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/meteoric_ionicons-sass/packages/meteoric_ionicons-sass.j //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteoric:ionicons-sass'] = {};

})();

//# sourceMappingURL=meteoric_ionicons-sass.js.map
