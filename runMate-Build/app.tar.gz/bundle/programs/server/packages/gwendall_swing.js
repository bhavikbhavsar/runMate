(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Swing;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gwendall:swing'] = {
  Swing: Swing
};

})();

//# sourceMappingURL=gwendall_swing.js.map
