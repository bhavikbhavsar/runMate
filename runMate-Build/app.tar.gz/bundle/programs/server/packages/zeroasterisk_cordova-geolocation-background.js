(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/zeroasterisk_cordova-geolocation-background/packages/zer //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zeroasterisk:cordova-geolocation-background'] = {};

})();

//# sourceMappingURL=zeroasterisk_cordova-geolocation-background.js.map
