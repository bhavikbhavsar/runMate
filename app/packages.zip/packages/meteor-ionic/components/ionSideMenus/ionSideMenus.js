Template.ionSideMenus.helpers({
  classes: function () {
    var classes = ['view', 'snap-drawers'];
    return classes.join(' ');
  }
});
