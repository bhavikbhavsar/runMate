Template.ionSideMenuContent.helpers({
  classes: function () {
    var classes = ['menu-content', 'snap-content', 'pane'];
    return classes.join(' ');
  }
});
