Meteor Swing
============

A swipeable cards interface packaged for Meteor. [Source](https://github.com/gajus/swing)

Installation
------------

``` sh
meteor add gwendall:swing
```
