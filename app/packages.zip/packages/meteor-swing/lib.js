Swing = gajus.Swing;
